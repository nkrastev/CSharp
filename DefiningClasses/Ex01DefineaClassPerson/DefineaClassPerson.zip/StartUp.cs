﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Person first = new Person("Pesho", 20);
            Person second = new Person("Gosho", 18);
            Person third = new Person("Stamat", 43);
        }
    }
}
