﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    class Car
    {
        //fields
        private string make;
        private string model;
        private int year;

        //properties
        public string Make { get; set; }
        public string Model { get; set; }

        public int Year { get; set; }
    }
}
