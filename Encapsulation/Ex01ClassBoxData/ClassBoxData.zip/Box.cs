﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex01ClassBoxData
{
    public class Box
    {
        //fields
        private double length;
        private double width;
        private double height;

        //ctor      
        public Box(double length, double width, double height)
        {
            this.Height = height;
            this.Length = length;
            this.Width = width;
        }

        //prop
        private double Length
        {
            get => this.length;
            set 
            {
                if (value<=0)
                {
                    throw new ArgumentException("Length cannot be zero or negative.");
                }
                this.length = value;
            } 
        }
        private double Width
        {
             get => this.width;
             set
             {
                if (value <= 0)
                {
                    throw new ArgumentException("Width cannot be zero or negative.");
                }
                this.width = value;
            }
        }
        private double Height
        {
            get => this.height;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Height cannot be zero or negative.");
                }
                this.height = value;
            }
        }

        //methods
        public double SurfaceArea() => (2 * this.Length * this.Width) + (2 * this.Length * this.Height) + (2 * this.Width * this.Height);

        public double Lateral() => (2 * this.Length * this.Height + 2 * this.Width* this.Height);

        public double Volume() => (this.Length * this.Width * this.Height);



    }
}
