﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Puppy : Dog
    {

        //methods
        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}
