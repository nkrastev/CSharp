﻿using System;
using System.Collections.Generic;

namespace _07Tuple
{
    class Program
    {
        static void Main()
        {
            var input = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);            
            var firstTuple = new Tuple<string, string>(input[0] + " " + input[1], input[2]);
            Console.WriteLine(firstTuple);

            input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var secondTuple = new Tuple<string, int>(input[0],int.Parse(input[1]));
            Console.WriteLine(secondTuple);

            input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var thirdTuple = new Tuple<int, double>(int.Parse(input[0]), double.Parse(input[1]));
            Console.WriteLine(thirdTuple);
        }
    }
}
