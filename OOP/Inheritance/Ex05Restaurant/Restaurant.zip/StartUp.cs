﻿namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //var coffee = new Coffee("c", 4, 5);
            //var tea = new Tea("t", 1, 1);

            //System.Console.WriteLine(tea.Milliliters);

            //System.Console.WriteLine(coffee.CoffeeMilliliters());
        }
    }
}