﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}
