﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex03Telephony
{
    public interface IBrowsable
    {
        public string Browse(string url);
    }
}
