﻿using System;

namespace Ex03Telephony
{
    class StartUp
    {
        static void Main()
        {
            var engine = new Engine();
            engine.Run();            
        }
    }
}
