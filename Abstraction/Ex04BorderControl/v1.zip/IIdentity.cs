﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04BorderControl
{
    interface IIdentity
    {
        public string Id { get; set; }
    }
}
